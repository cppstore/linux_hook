#include <stdio.h>
#include <string.h>
#include <elf.h>
#include <sys/types.h>
#include <stdio.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <sys/user.h>
#include <link.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
//gcc hook3.c -o hook3 -ldl
#if defined(__x86_64__)
    #define ARCH "x86_64"
    #define IMAGE_ADDR 0x00400000
    typedef Elf64_Ehdr Elf_Ehdr;
    typedef Elf64_Phdr Elf_Phdr;
    typedef Elf64_Shdr Elf_Shdr;
    typedef Elf64_Sym  Elf_Sym;
    typedef Elf64_Dyn Elf_Dyn;
    typedef Elf64_Word Elf_Word;
    typedef Elf64_Word Dyn_Val;
    typedef Elf64_Addr Elf_Addr;
    #define ELF_ST_TYPE(X) ELF64_ST_TYPE(X)
    #define ELF_ST_BIND(X) ELF64_ST_BIND(X)
    #define ELF_ST_VISIBILITY(X) ELF64_ST_VISIBILITY(X)
    typedef Elf64_Rel  Elf_Rel;
    typedef Elf64_Rela Elf_Rela;
    #define ELF_R_SYM(X)  ELF32_R_SYM(X)
    #define ELF_R_TYPE(X) ELF64_R_TYPE(X)
#endif

#if defined(__i386__)
    #define ARCH "x86"
    #define IMAGE_ADDR 0x08048000
    typedef Elf32_Ehdr Elf_Ehdr;
    typedef Elf32_Phdr Elf_Phdr;
    typedef Elf32_Shdr Elf_Shdr;
    typedef Elf32_Sym  Elf_Sym;
    typedef Elf32_Dyn Elf_Dyn;
    typedef Elf32_Word Elf_Word;
    typedef Elf32_Word Dyn_Val;
    typedef Elf32_Addr Elf_Addr;
    #define ELF_ST_TYPE(X) ELF32_ST_TYPE(X)
    #define ELF_ST_BIND(X) ELF32_ST_BIND(X)
    #define ELF_ST_VISIBILITY(X) ELF32_ST_VISIBILITY(X)
    typedef Elf32_Rel  Elf_Rel;
    typedef Elf32_Rela Elf_Rela;
    #define ELF_R_SYM(X)  ELF32_R_SYM(X)
    #define ELF_R_TYPE(X) ELF32_R_TYPE(X)
#endif


#define STRLEN 1024


struct user_regs_struct oldregs;//专门用于保存寄存器的值

Elf_Addr lmap_addr;
Elf_Addr phdr_addr;
Elf_Addr dyn_addr;

struct lmap_result 
{
    Elf_Addr symtab;
    Elf_Addr strtab;
    Elf_Addr jmprel;
    Elf_Addr reldyn;
    uint64_t link_addr;
    uint64_t nsymbols;
    uint64_t nrelplts;
    uint64_t nreldyns;
};

void error_msg(const char *s)
{
    perror(s);
    exit(-1);
}

static void ptrace_getregs(pid_t pid, struct user_regs_struct *regs)
{
    if(ptrace(PTRACE_GETREGS, pid, NULL, regs)) 
    {
        error_msg("ptrace_getregs error!\n");
    }
}

static void ptrace_setregs(pid_t pid, struct user_regs_struct *regs)
{
    if(ptrace(PTRACE_SETREGS, pid, NULL, regs)) {
        error_msg("ptrace_setregs error\n");
    }
}

void ptrace_attach(pid_t pid)
{
    if(ptrace(PTRACE_ATTACH, pid, NULL, NULL) < 0)
    {
        error_msg("ptrace_attach error\n");
    }
    
    waitpid(pid, NULL, WUNTRACED);
    
    ptrace_getregs(pid, &oldregs);
}

void ptrace_detach(pid_t pid)
{
    ptrace_setregs(pid, &oldregs);

    if(ptrace(PTRACE_DETACH, pid, NULL, NULL) < 0)
    {
        error_msg("ptrace_detach error\n");
    }
}

/* 读指定进程 */
int ptrace_getdata(int pid, unsigned long addr, void *vptr, int len)
{
    int i,count;
    long word;
    unsigned long *ptr = (unsigned long *)vptr;

    i = count = 0;
    while (count < len)
    {
        word = ptrace(PTRACE_PEEKTEXT, pid, addr + count, NULL);
        while(word < 0)
        {
            if(errno == 0)
                break;
            perror("ptrace_getdata failed");
            return 2;
        }
        count += sizeof(long);
        ptr[i++] = word;
    }
    return 0;
}

/* 写指定进程地址 */
void ptrace_setdata(int pid, unsigned long addr, void *vptr, int len)
{
    int count;
    long word;

    count = 0;
    while(count < len)
    {
        memcpy(&word, vptr + count, sizeof(word));
        word = ptrace(PTRACE_POKETEXT, pid, addr + count, word);
        count += sizeof(long);

        if(errno != 0)
            printf("ptrace_setdata failed\t %ld\n", addr + count);
    }
}

/*
 在进程指定地址读一个字符串
 */
unsigned int ptrace_getstr(int pid, unsigned long addr, char *buf, unsigned int len)
{
    char *str = (char *) malloc(64);
    int i,count;
    long word;
    char *pa;

    i = count = 0;
    pa = (char *)&word;

    while(i <= 60)
    {
        word = ptrace(PTRACE_PEEKTEXT, pid, addr + count, NULL);
        count += 4;

        if (pa[0] == 0)
        {
            str[i] = 0;
            break;
        }
        else
            str[i++] = pa[0];

        if (pa[1] == 0)
        {
            str[i] = 0;
            break;
        }
        else
            str[i++] = pa[1];

        if (pa[2] ==0)
        {
            str[i] = 0;
            break;
        }
        else
            str[i++] = pa[2];

        if (pa[3] ==0)
        {
            str[i] = 0;
            break;
        }
        else
            str[i++] = pa[3];
    }
    
    if (i < len) 
    {
       memset(buf,0,len);
       strncpy(buf, str, i);
    }

   return i;
}

/* 取得指向link_map链表首项的指针 */
struct link_map* get_linkmap(int pid)
{
    int i;
    Elf_Ehdr *ehdr = (Elf_Ehdr *) malloc(sizeof(Elf_Ehdr)); 
    Elf_Phdr *phdr = (Elf_Phdr *) malloc(sizeof(Elf_Phdr));
    Elf_Dyn  *dyn = (Elf_Dyn *) malloc(sizeof(Elf_Dyn));
    Elf_Addr *gotplt;

    // 读取文件头
    ptrace_getdata(pid, IMAGE_ADDR, ehdr, sizeof(Elf_Ehdr));

    // 获取program headers table的地址
    phdr_addr = IMAGE_ADDR + ehdr->e_phoff;
    
    // 遍历program headers table，找到.dynamic
    for (i = 0; i < ehdr->e_phnum; i++) 
    {
        ptrace_getdata(pid, phdr_addr + i * sizeof(Elf_Phdr), phdr, sizeof(Elf_Phdr));
        if (phdr->p_type == PT_DYNAMIC) 
        {
            dyn_addr = phdr->p_vaddr;
            break;
        }
    }
    
    if (0 == dyn_addr) 
    {
        error_msg("cannot find the address of .dynamin\n");
    } else 
    {
        printf("[+]the address of .dynamic is %p\n", (void *)dyn_addr);
    }

    // 遍历.dynamic，找到.got.plt 
    for (i = 0; i * sizeof(Elf_Dyn) <= phdr->p_memsz; i++ )
    {
        ptrace_getdata(pid, dyn_addr + i * sizeof(Elf_Dyn), dyn, sizeof(Elf_Dyn));
        if (dyn->d_tag == DT_PLTGOT) 
        {
            gotplt = (Elf_Addr *)(dyn->d_un.d_ptr);
            break;
        }
    }
    if (NULL == gotplt) 
    {
        error_msg("cannot find the address of .got.plt\n");

    }else 
    {
        printf("[+]the address of .got.plt is %p\n", gotplt);
    }

    // 获取link_map地址
    ptrace_getdata(pid, (Elf_Addr)(gotplt + 1), &lmap_addr, sizeof(Elf_Addr));
    printf("[+]the address of link_map is %p\n", (void *)lmap_addr);

    free(ehdr);
    free(phdr);
    free(dyn);

    return (struct link_map *)lmap_addr;
}

/*
 * 取得给定link_map指向的SYMTAB、STRTAB、RELPLT、REPLDYN信息
 * 这些地址信息将被保存到全局变量中，以方便使用
 */
struct lmap_result *handle_one_lmap(int pid, struct link_map *lm)
{
    Elf_Addr dyn_addr;
    Elf_Dyn  *dyn = (Elf_Dyn *)calloc(1, sizeof(Elf_Dyn));
    struct lmap_result *lmret = NULL;

    // 符号表
    Elf_Addr    symtab;
    Dyn_Val     syment;
    Dyn_Val     symsz;
    // 字符串表
    Elf_Addr    strtab;
    // rel.plt
    Elf_Addr    jmprel;
    Dyn_Val     relpltsz;
    // rel.dyn
    Elf_Addr    reldyn;
    Dyn_Val     reldynsz;
    // size of one REL relocs or RELA relocs
    Dyn_Val     relent;
    // 每个lmap对应的库的映射基地址
    Elf_Addr    link_addr;

    link_addr = lm->l_addr;
    dyn_addr = lm->l_ld;

    ptrace_getdata(pid, dyn_addr, dyn, sizeof(Elf_Dyn));

    while(dyn->d_tag != DT_NULL)
    {
        switch(dyn->d_tag)
        {
        // 符号表
            case DT_SYMTAB:
            symtab = dyn->d_un.d_ptr;
            break;
            case DT_SYMENT:
            syment = dyn->d_un.d_val;
            break;
            case DT_SYMINSZ:
            symsz = dyn->d_un.d_val;
            break;
        // 字符串表
            case DT_STRTAB:
            strtab = dyn->d_un.d_ptr;
            break;
        // rel.plt, Address of PLT relocs
            case DT_JMPREL:
            jmprel = dyn->d_un.d_ptr;
            break;
        // rel.plt, Size in bytes of PLT relocs
            case DT_PLTRELSZ:
            relpltsz = dyn->d_un.d_val;
            break;
        // rel.dyn, Address of Rel relocs
            case DT_REL:
            case DT_RELA:
            reldyn = dyn->d_un.d_ptr;
            break;
        // rel.dyn, Size of one Rel reloc
            case DT_RELENT:
            case DT_RELAENT:
            relent = dyn->d_un.d_val;
            break;
        //rel.dyn  Total size of Rel relocs
            case DT_RELSZ:
            case DT_RELASZ:
            reldynsz = dyn->d_un.d_val;
            break;
        }
        ptrace_getdata(pid, dyn_addr += (sizeof(Elf_Dyn)/sizeof(Elf_Addr)), dyn, sizeof(Elf_Dyn));
    }
    if (0 == syment || 0 == relent)
    {
        printf("[-]Invalid ent, syment=%u, relent=%u\n", (unsigned)syment, (unsigned)relent);
        return lmret;
    }

    lmret = (struct lmap_result *)calloc(1, sizeof(struct lmap_result));
    lmret->symtab = symtab;
    lmret->strtab = strtab;
    lmret->jmprel = jmprel;
    lmret->reldyn = reldyn;
    lmret->link_addr = link_addr;
    lmret->nsymbols = symsz / syment;
    lmret->nrelplts = relpltsz / relent;
    lmret->nreldyns = reldynsz / relent;
    
    free(dyn);

    return lmret;
}

Elf_Addr find_symbol_in_linkmap(int pid, struct link_map *lm, char *sym_name)
{
    int i = 0;
    char buf[STRLEN] = {0};
    unsigned int nlen = 0;
    Elf_Addr ret;
    Elf_Sym *sym = (Elf_Sym *)malloc(sizeof(Elf_Sym)); 

    struct lmap_result *lmret = handle_one_lmap(pid, lm);

    for(i = 0; i >= 0; i++) 
    {
        // 读取link_map的符号表
        ptrace_getdata(pid, lmret->symtab + i * sizeof(Elf_Sym), sym, sizeof(Elf_Sym));

        // 全为0，是符号表的第一项
        if (!sym->st_name && !sym->st_size && !sym->st_value) 
        {
            continue;
        }
        nlen = ptrace_getstr(pid, lmret->strtab + sym->st_name, buf, 128);
        if (buf[0] && (32 > buf[0] || 127 == buf[0])) 
        {
            printf(">> nothing found in this so...\n\n");
            return 0;
        }

        
        if (strcmp(buf, sym_name) == 0) 
        {
            printf("[+]has find the symbol name: %s\n",buf);
            if(sym->st_value == 0) 
            {
                // 值为0，代表这个符号本身就是重定向的内容
                continue;
            }else 
            {
                // 否则说明找到了符号
                return (lmret->link_addr + sym->st_value);
            }
        }

    }

    free(sym);
    return 0;
}

/*符号查找，该函数主要实现link_map遍历 */
Elf_Addr find_symbol(int pid, Elf_Addr lm_addr, char *sym_name)
{
    char buf[STRLEN] = {0};
    struct link_map lmap;
    unsigned int nlen = 0;

    while (lm_addr) 
    {
        // 读取link_map结构内容
        ptrace_getdata(pid, lm_addr, &lmap, sizeof(struct link_map));
        lm_addr = (Elf_Addr)(lmap.l_next);

        // 判断l_name是否有效
        if (0 == lmap.l_name) 
        {
            printf("[-]invalid address of l_name\n");
            continue;
        }
        nlen = ptrace_getstr(pid, (Elf_Addr)lmap.l_name, buf, 128);
        if (0 == nlen || 0 == strlen(buf)) 
        {
            printf("[-]invalud name of link_map at %p\n", (void *)lmap.l_name);
            continue;
        }
        printf(">> start search symbol in %s:\n", buf);

        Elf_Addr sym_addr = find_symbol_in_linkmap(pid, &lmap, sym_name);
        if (sym_addr) 
        {
            return sym_addr;
        }
    }

    return 0;
}

/*
在进程自身的映象中（即不包括动态共享库，无须遍历link_map链表）获得各种动态信息
*/
struct lmap_result *get_dyn_info(int pid)
{
    int i = 0;
    Dyn_Val relpltsz;
    Dyn_Val relent;
    Elf_Dyn *dyn = (Elf_Dyn *) malloc(sizeof(Elf_Dyn));
    struct lmap_result *lmret = NULL;
    lmret = (struct lmap_result *)calloc(1, sizeof(struct lmap_result));

    ptrace_getdata(pid, dyn_addr + i * sizeof(Elf_Dyn), dyn, sizeof(Elf_Dyn));
    i++;

    while(dyn->d_tag)
    {
        switch(dyn->d_tag)
        {
            case DT_SYMTAB:
            //puts("DT_SYMTAB");
            lmret->symtab = dyn->d_un.d_ptr;
            break;
            case DT_STRTAB:
            //puts("DT_STRTAB");
            lmret->strtab = dyn->d_un.d_ptr;
            break;
            case DT_JMPREL:
            //puts("DT_JMPREL");
            lmret->jmprel = dyn->d_un.d_ptr;
            break;
            case DT_PLTRELSZ:
            //puts("DT_PLTRELSZ");
            relpltsz = dyn->d_un.d_val;
            break;
            case DT_RELENT:
            case DT_RELAENT:
            //puts("DT_RELENT");
            relent = dyn->d_un.d_val;
            break;
        }
        ptrace_getdata(pid, dyn_addr + i * sizeof(Elf_Dyn), dyn, sizeof(Elf_Dyn));
        i++;
    }
    lmret->nrelplts = relpltsz / relent;
    free(dyn);

    return lmret;
}

// 查找符号的重定位地址 
Elf_Addr find_sym_in_rel(int pid, char *sym_name)
{
    Elf_Rel *rel = (Elf_Rel *) malloc(sizeof(Elf_Rel));
    Elf_Sym *sym = (Elf_Sym *) malloc(sizeof(Elf_Sym));
    int i;
    char str[STRLEN] = {0};
    unsigned long ret;
    struct lmap_result *lmret = get_dyn_info(pid);

    for (i = 0; i<lmret->nrelplts; i++) 
    {
        ptrace_getdata(pid, lmret->jmprel + i*sizeof(Elf_Rela), rel, sizeof(Elf_Rela));
        ptrace_getdata(pid, lmret->symtab + ELF64_R_SYM(rel->r_info) * sizeof(Elf_Sym), sym, sizeof(Elf_Sym));
        int n = ptrace_getstr(pid, lmret->strtab + sym->st_name, str, STRLEN);
        printf("self->st_name: %s, self->r_offset = %p\n",str, rel->r_offset);
        if (strcmp(str, sym_name) == 0) 
        {
            break;
        }
    }
    if (i == lmret->nrelplts)
        ret = 0;
    else
        ret = rel->r_offset;
    free(rel);
    return ret;
}

/*
#define RTLD_LAZY           0x00001
#define RTLD_NOW            0x00002
#define RTLD_BINDING_MASK   0x3
#define RTLD_NOLOAD         0x00004
#define RTLD_DEEPBIND       0x00008
#define RTLD_GLOBAL         0x00100
#define RTLD_LOCAL          0
#define RTLD_NODELETE       0x01000
*/

int inject_code(pid_t pid, unsigned long dlopen_addr, char *libc_path)
{
    char sbuf1[STRLEN], sbuf2[STRLEN];
    struct user_regs_struct regs, saved_regs;
    int status;
    puts(">> start inject_code to call the dlopen");

    ptrace_getregs(pid, &regs);//获取所有寄存器值
    ptrace_getdata(pid, regs.rsp + STRLEN, sbuf1, sizeof(sbuf1));
    ptrace_getdata(pid, regs.rsp, sbuf2, sizeof(sbuf2));//获取栈上数据并保存在sbuf1、2

    /*用于引发SIGSEGV信号的ret内容*/
    unsigned long ret_addr = 0x666;

    ptrace_setdata(pid, regs.rsp, (char *)&ret_addr, sizeof(ret_addr));
    ptrace_setdata(pid, regs.rsp + STRLEN, libc_path, strlen(libc_path) + 1); 

    memcpy(&saved_regs, &regs, sizeof(regs));

    printf("before inject:rsp=%zx rdi=%zx rsi=%zx rip=%zx\n", regs.rsp,regs.rdi, regs.rsi, regs.rip);

    regs.rdi = regs.rsp + STRLEN;
    regs.rsi = RTLD_NOW|RTLD_GLOBAL|RTLD_NODELETE;
    regs.rip = dlopen_addr+2;

    printf("after inject:rsp=%zx rdi=%zx rsi=%zx rip=%zx\n", regs.rsp,regs.rdi, regs.rsi, regs.rip);

    if (ptrace(PTRACE_SETREGS, pid, NULL, &regs) < 0)
    {//设置寄存器
        error_msg("inject_code:PTRACE_SETREGS 1 failed!");
    }

    if (ptrace(PTRACE_CONT, pid, NULL, NULL) < 0)
    {//设置完寄存器后让目标进程继续运行
        error_msg("inject_code:PTRACE_CONT failed!");
    }


    waitpid(pid, &status, 0);//按照最后的ret指令会使得rip=0x666，从而引发SIGSEGV
    ptrace_getregs(pid, &regs);
    printf("after waitpid inject:rsp=%zx rdi=%zx rsi=%zx rip=%zx\n", regs.rsp,regs.rdi, regs.rsi, regs.rip);

    //恢复现场，恢复所有寄存器和栈上数据
    if (ptrace(PTRACE_SETREGS, pid, 0, &saved_regs) < 0)
    {
        error_msg("inject_code:PTRACE_SETREGS 2 failed!");;
    }
    ptrace_setdata(pid, saved_regs.rsp + STRLEN, sbuf1, sizeof(sbuf1));
    ptrace_setdata(pid, saved_regs.rsp, sbuf2, sizeof(sbuf2));
    puts("-----inject_code done------");
    return 0;
}


void To_detach(int pid)
{
    printf("***detach***\n");
    ptrace_detach(pid);
    exit(0);
}

//程序开始
int main(int argc, char *argv[])
{
    int pid;
    int status = 0;
    struct link_map *map;
    char sym_name[STRLEN];
    char libpath[STRLEN];
    char oldfunname[STRLEN];
    char newfunname[STRLEN];
    Elf_Addr new_sym_addr,old_sym_addr,old_rel_addr,dlopen_addr,target_addr;

    if(argc < 5)
    {
        printf("usage: ./hook hook_so_path oldfunname newfunname pid\n");
        exit(-1);
    }

    /* 从命令行取得新库名称*/
    memset(libpath,0,sizeof(libpath));
    memcpy(libpath,argv[1],strlen(argv[1]));
    /* 从命令行取得旧函数的名称*/
    memset(oldfunname,0,sizeof(oldfunname));
    memcpy(oldfunname,argv[2],strlen(argv[2]));
    /* 从命令行取得新函数的名称*/
    memset(newfunname,0,sizeof(newfunname));
    memcpy(newfunname,argv[3],strlen(argv[3]));
    /* 从命令行取得目标进程PID*/
    pid = atoi(argv[4]);

    puts("---------------------------------");
    printf("target pid = %d\n",pid);
    printf("target oldfunname: %s\n",oldfunname);
    printf("hook so path: %s\n",libpath);
    printf("hook newfunname: %s\n",newfunname);
    puts("---------------------------------\n");

    /* 关联到目标进程*/
    ptrace_attach(pid);
    
    /* 得到指向link_map链表的指针 */
    map = get_linkmap(pid);
    
    /* 查找要被替换的函数 */
    old_sym_addr = find_symbol(pid, map, oldfunname);      
    if(old_sym_addr == 0)
    {
        error_msg("NOT FOUND: oldfunname");
        To_detach(pid);
    }
    printf("found %s at addr %p\n", oldfunname, old_sym_addr);


    /* 发现__libc_dlopen_mode，并调用它加载patch.so动态链接库 */
    dlopen_addr = find_symbol(pid, map, "__libc_dlopen_mode");
    if(dlopen_addr == 0)
    {
        error_msg("NOT FOUND: __libc_dlopen_mode");
        To_detach(pid);
    }
    printf("found __libc_dlopen_mode at addr %p\n", dlopen_addr);   


    inject_code	(pid, dlopen_addr, libpath);

    /* 找到新函数的地址 */
    new_sym_addr = find_symbol(pid, map, newfunname);
    if(new_sym_addr == 0)
    {
        error_msg("NOT FOUND: newfunname");
        To_detach(pid);
    }
    printf("===> found %s at addr %p\n", newfunname, new_sym_addr);

    /* 找到旧函数在重定向表的地址 */          
    old_rel_addr = find_sym_in_rel(pid, oldfunname);
    if(old_rel_addr == 0)
    {
        error_msg("NOT FOUND: old func rel_addr");
        To_detach(pid);
    }
    printf("oldfunname: %s  rel addr:%p\n",oldfunname,old_rel_addr);

    ptrace_getdata(pid, old_rel_addr, &target_addr, sizeof(Elf_Addr));
    ptrace_setdata(pid, old_rel_addr, &new_sym_addr, sizeof(Elf_Addr));
    printf("oldfunction addr:%p\n",target_addr);
    printf("newfunction addr:%p\n",new_sym_addr);

    puts("hook has done!");
    sleep(1);
    To_detach(pid);


    return 0;
}
