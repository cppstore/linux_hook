#include <stdio.h>
#include <unistd.h>

int main()
{
	int num=10;
	printf("my pid is %d\n", getpid());
	puts("start hook?");
	// getchar();
	while(--num)
	{
		puts("hello?");
   		sleep(1);
	}
    

    // getchar();
    return 0;
}
//gcc target.c -o target
