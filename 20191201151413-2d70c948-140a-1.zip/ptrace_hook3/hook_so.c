#include <stdio.h>
//gcc hook_so.c -o hook_so.so -fPIC --shared
int newputs(const char *str)
{
    write(1,"hook puts! ",11);
    puts(str);
    return 0;
}


/* __attribute__((constructor))
void loadMsg()
{
	puts("hook.so has been injected!");
	puts("now let's do somesthing...");
	printf("->pid:%d\n\n", getpid());
}


__attribute__((destructor))
void eixtMsg()
{
	puts("bye bye~");

} */
